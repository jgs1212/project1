package com.jwt.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.jwt.model.JobAlert;
import com.jwt.model.NewApplicant;
import com.jwt.service.JobAlertService;
import com.jwt.service.NewApplicantService;
import com.jwt.util.HtmlEmailSender;
import com.jwt.vo.JobAlertInfo;
import com.jwt.vo.NewApplicantInfo;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;



@RestController
public class JobAlertController {
	
	@Autowired
	private	JobAlertService jobAlertService;
	
	@RequestMapping(value = "/jobalert")
	public ModelAndView index(ModelAndView model,@ModelAttribute JobAlertInfo JobAlertInfo) 
	{
	
		model.addObject("JobAlertInfo", JobAlertInfo);
        model.setViewName("jobalert");
	     return model;
	}
	
	
	@RequestMapping(value = "/saveJobAlertInfoDetails", method = RequestMethod.POST)
	public ModelAndView saveJobAlertInfoDetails(@ModelAttribute JobAlertInfo JobAlertInfo, ModelAndView model,HttpSession session) throws MessagingException
	{
		
		JobAlert newjobalert =new JobAlert();
		newjobalert.setLocation(JobAlertInfo.getLocation());
		newjobalert.setDetail(JobAlertInfo.getDetail());
		newjobalert.setDate(JobAlertInfo.getDate());
		newjobalert.setRequiretime(JobAlertInfo.getRequiretime());
		newjobalert.setPayment(JobAlertInfo.getPayment());
		if (newjobalert.getJobid()== 0) { 
			
			jobAlertService.saveJobAlert(newjobalert);
		} 
		else {
		}
		
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String subject = "Re:New JOB Alert Posted Successfully!!!";
		
		
		List<NewApplicant> listNewApplicant = jobAlertService.getNewApplicantdtls();
		for (NewApplicant eid : listNewApplicant) 
		{
			System.out.println(eid.getEmail());
			
			String mailTo = eid.getEmail();
			
			String message = "<font size=5><b><i>Greetings!</i></b><br><br>";
			message += "<b>Dear "+eid.getName()+"</b><br>";
			message += "<font color=red>Below New Job Posted Details</font><br>";
			message += "<b>LOCATION OF JOB: </b>"+JobAlertInfo.getLocation()+"<br>";
			message += "<b>DATE OF JOB:</b> "+formatter.format(JobAlertInfo.getDate())+"<br>";
			message += "<b>JOB DETAILS:</b> "+JobAlertInfo.getDetail()+"<br>";
			message += "<b>TIME REQUIRED:</b> "+JobAlertInfo.getRequiretime()+"<br>";
			message += "<b>TOTAL CREW PAYMENT:</b> $"+JobAlertInfo.getPayment()+"<br></font>";
			

			HtmlEmailSender mailer = new HtmlEmailSender();
		    System.out.println("mailer.getHost()"+mailer.getHost());
			
			try {
				mailer.sendHtmlEmail(mailer.getHost(), mailer.getPort(), mailer.getMailFrom(), mailer.getPassword(), mailTo,subject, message);
				System.out.println("Email sent.");
			} catch (Exception ex) {
				System.out.println("Failed to sent email.");
				ex.printStackTrace();
			}
		
		
		}
		
			
		model.addObject("JobAlertInfo", "empty");
		session.setAttribute("errmsg","New Job Posted & Mail Sent Sucessfully!!!");
		return new ModelAndView("redirect:/");
        
       
	}

}
