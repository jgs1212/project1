package com.jwt.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.jwt.model.NewApplicant;

import com.jwt.service.NewApplicantService;
import com.jwt.util.HtmlEmailSender;
import com.jwt.vo.NewApplicantInfo;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;



@RestController
public class NewApplicantController {
	

	@Autowired
	private	NewApplicantService newApplicantService;
	

	@RequestMapping(value = "/")
	public ModelAndView index(ModelAndView model,@ModelAttribute NewApplicantInfo NewApplicantInfo) 
	{
	
		model.addObject("NewApplicantInfo", NewApplicantInfo);
        model.setViewName("index");
	     return model;
	}
	
	
	
	
	@RequestMapping(value = "/saveNewApplicantDetails", method = RequestMethod.POST)
	public ModelAndView saveNewApplicantDetails(@ModelAttribute NewApplicantInfo newApplicantInfo, ModelAndView model,HttpSession session) throws MessagingException
	{
		
		NewApplicant newApplicant =new NewApplicant();
		 
		newApplicant.setName(newApplicantInfo.getName());
		newApplicant.setEmail(newApplicantInfo.getEmail());
		newApplicant.setDate(newApplicantInfo.getDate());
		newApplicant.setDetail(newApplicantInfo.getDetail());
		newApplicant.setExp(newApplicantInfo.getExp());
		newApplicant.setJobdesc(newApplicantInfo.getJobdesc());
		if (newApplicant.getNewjobid() == 0) { 
			
			newApplicantService.saveNewApplicant(newApplicant);
		} 
		else {
		}
		
		
      
			DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
						// outgoing message information
			String mailTo = newApplicantInfo.getEmail();
			String subject = "Re:New Applicant Register Successfully!!!";

			
			String message = "<font size=5><b><i>Greetings!</i></b><br><br>";
			message += "<b>Dear "+newApplicantInfo.getName()+"</b><br>";
			message += "<font color=red>Below New Applicant Register Details</font><br>";
			message += "<b>JOB: </b>"+newApplicantInfo.getJobdesc()+"<br>";
			message += "<b>DATE OF JOB:</b> "+formatter.format(newApplicantInfo.getDate())+"<br>";
			message += "<b>ABOUT:</b> "+newApplicantInfo.getDetail()+"<br>";
			message += "<b>YEARS OF EXPERIENCE:</b> "+newApplicantInfo.getExp()+"<br></font>";
			

			HtmlEmailSender mailer = new HtmlEmailSender();

			try {
				mailer.sendHtmlEmail(mailer.getHost(), mailer.getPort(), mailer.getMailFrom(), mailer.getPassword(), mailTo,subject, message);
				System.out.println("Email sent.");
			} catch (Exception ex) {
				System.out.println("Failed to sent email.");
				ex.printStackTrace();
			}
		
		model.addObject("NewApplicantInfo", "empty");
		session.setAttribute("errmsg","New Applicant Added & Mail Sent Sucessfully!!!");
		//model.setViewName("index");
        //return model;
		return new ModelAndView("redirect:/");
        
       
	}
	

	
	
}
