package com.jwt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jwt.dao.NewApplicantDao;

import com.jwt.model.NewApplicant;


@Service("NewApplicantService")
@Transactional
public class NewApplicantServiceImpl implements NewApplicantService {

	 @Autowired
	 private NewApplicantDao newApplicantDao;


		@Override
		public void saveNewApplicant(NewApplicant newApplicant)
		
		{
			newApplicantDao.saveNewApplicant(newApplicant);
			
		}
		
		
	 
		

		
}