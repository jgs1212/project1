package com.jwt.service;

import java.util.List;

import com.jwt.model.JobAlert;
import com.jwt.model.NewApplicant;



public interface JobAlertService {

	
	public void saveJobAlert(JobAlert jobAlert);
	public List<NewApplicant> getNewApplicantdtls();
}



