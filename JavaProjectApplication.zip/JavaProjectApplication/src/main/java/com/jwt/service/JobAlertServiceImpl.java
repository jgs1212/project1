package com.jwt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jwt.dao.JobAlertDao;
import com.jwt.dao.NewApplicantDao;
import com.jwt.model.JobAlert;
import com.jwt.model.NewApplicant;


@Service("JobAlertService")
@Transactional
public class JobAlertServiceImpl implements JobAlertService {

	 @Autowired
	 private JobAlertDao jobAlertDao;

		@Override
		public void saveJobAlert(JobAlert jobAlert) {
			jobAlertDao.saveJobAlert(jobAlert);
			
		}

		@Override
		public List<NewApplicant> getNewApplicantdtls() {
			
			return jobAlertDao.getNewApplicantdtls();
		}
		
}