package com.jwt.service;

import java.util.List;


import com.jwt.model.NewApplicant;



public interface NewApplicantService {

	
	public void saveNewApplicant(NewApplicant newApplicant);
}



