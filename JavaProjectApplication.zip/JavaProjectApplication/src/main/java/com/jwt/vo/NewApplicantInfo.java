package com.jwt.vo;


import java.util.Date;

import org.springframework.web.multipart.commons.CommonsMultipartFile;



public class NewApplicantInfo {
	
	private int newjobid;
	
	private String name;
	private String email;
	private String jobdesc;
	private Date date;
	private String detail;
	private String exp;

	public NewApplicantInfo()
    {
    	
    }

	public int getNewjobid() {
		return newjobid;
	}

	public void setNewjobid(int newjobid) {
		this.newjobid = newjobid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJobdesc() {
		return jobdesc;
	}

	public void setJobdesc(String jobdesc) {
		this.jobdesc = jobdesc;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}
    
	

}