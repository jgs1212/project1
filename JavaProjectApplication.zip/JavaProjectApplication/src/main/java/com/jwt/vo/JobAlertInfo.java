package com.jwt.vo;


import java.util.Date;

import javax.persistence.Column;

import org.springframework.web.multipart.commons.CommonsMultipartFile;


public class JobAlertInfo {
	
	private int jobid;
	private String jobdesc;
    private String location;
    private Date date;
    private String detail;
    private String requiretime;
    private Double payment;

	public JobAlertInfo()
    {
    	
    }

	public int getJobid() {
		return jobid;
	}

	public void setJobid(int jobid) {
		this.jobid = jobid;
	}

	public String getJobdesc() {
		return jobdesc;
	}

	public void setJobdesc(String jobdesc) {
		this.jobdesc = jobdesc;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getRequiretime() {
		return requiretime;
	}

	public void setRequiretime(String requiretime) {
		this.requiretime = requiretime;
	}

	public Double getPayment() {
		return payment;
	}

	public void setPayment(Double payment) {
		this.payment = payment;
	}

}