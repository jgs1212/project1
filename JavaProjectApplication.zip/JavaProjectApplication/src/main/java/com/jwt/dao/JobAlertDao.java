package com.jwt.dao;

import java.util.List;

import com.jwt.model.JobAlert;
import com.jwt.model.NewApplicant;


public interface JobAlertDao 
{

	
	public void saveJobAlert(JobAlert jobAlert);
	public List<NewApplicant> getNewApplicantdtls();
	
}
