package com.jwt.dao;

import java.util.List;


import com.jwt.model.NewApplicant;


public interface NewApplicantDao 
{

	
	public void saveNewApplicant(NewApplicant newApplicant);
	
}
