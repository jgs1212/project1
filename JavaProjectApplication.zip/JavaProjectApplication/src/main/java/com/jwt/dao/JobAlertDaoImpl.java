package com.jwt.dao;

import java.util.List;
import java.util.UUID;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jwt.model.JobAlert;
import com.jwt.model.NewApplicant;


@Repository("JobAlertDao")
public class JobAlertDaoImpl implements JobAlertDao {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public void saveJobAlert(JobAlert jobAlert) 
	{
		Session session = sessionFactory.getCurrentSession();
   		session.save(jobAlert);
		
	} 
	public List<NewApplicant> getNewApplicantdtls()
	{
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(" from NewApplicant");
		System.out.println("query list==="+query.list());
		return (List<NewApplicant>)query.list();
	}
	
}


